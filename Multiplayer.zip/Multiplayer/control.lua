require "defines"

normalattacksentevent = game.generateeventname()
landingattacksentevent = game.generateeventname()
remote.addinterface("freeplay",
{
  setattackdata = function(data)
    glob.attackdata = data
  end,

  getattackdata = function()
    return glob.attackdata
  end,

  getnormalattacksentevent = function()
    return normalattacksentevent
  end,

  getlandingattacksentevent = function()
    return landingattacksentevent
  end
})

initattackdata = function()
  glob.attackdata = {
    -- whether all attacks are enabled
    enabled = true,
    -- this script is allowed to change the attack values attackcount and untilnextattack
    changevalues = true,
    -- what distracts the creepers during the attack
   distraction = defines.distraction.byenemy,
    -- number of units in the next attack
    attackcount = 5,
    -- time to the next attack
    untilnextattack = 60 * 60 * 60,
  }
end

game.onevent(defines.events.onplayercreated, function(event)
  local player = game.getplayer(event.playerindex)
  player.insert{name="iron-plate", count=8}
  player.insert{name="pistol", count=1}
  player.insert{name="basic-bullet-magazine", count=10}
  player.insert{name="burner-mining-drill", count = 1}
  player.insert{name="stone-furnace", count = 1}
  if (#game.players <= 1) then
    game.showmessagedialog{text = {"msg-intro"}}
  end
end)

game.oninit(function()
  initattackdata()
end)

-- for backwards compatibility
game.onload(function()
  if glob.attackdata == nil then
    initattackdata()
    if glob.attackcount ~= nil then glob.attackdata.attackcount = glob.attackcount end
    if glob.untilnextattacknormal ~= nil then glob.attackdata.untilnextattack = glob.untilnextattacknormal end
  end
  if glob.attackdata.distraction == nil then glob.attackdata.distraction = defines.distraction.byenemy end
end)

game.onevent(defines.events.ontick, function(event)
  for index, player in pairs(game.players) do
    if not player.character then
      goto continue
    end
    -- handling the case once the rocket defense has been built
    if player.force.getshiplandinginprogress() then
      local timeleft = player.force.gettimetoland()
      if timeleft == 0 then
        game.setgamestate{gamefinished=true, playerwon=true}
      end
      local secondsleft = math.floor(timeleft / 60)
      local minutes = math.floor((secondsleft)/60)
      local seconds = math.floor(secondsleft - 60*minutes)
      player.setgoaldescription("Time until the fleet lands: " .. string.format("%d:%02d", minutes, seconds), true)
      if glob.attackdata.enabled then
        if glob.attackdata.changevalues then glob.attackdata.untilnextattack = glob.attackdata.untilnextattack - 1 end
        if glob.attackdata.untilnextattack <= 0 then
          local unitssent = game.setmulticommand({type=defines.command.attack,
          target=player.character,
          distraction=glob.attackdata.distraction},
          glob.attackdata.attackcount)
          if glob.attackdata.changevalues then glob.attackdata.untilnextattack = 60 * 10 end
          game.raiseevent(landingattacksentevent, {unitssent=unitssent})
        end
      end
    end
    ::continue::
  end
end)

game.onevent(defines.events.onshiplandingstart, function(event)
  if glob.attackdata.changevalues then
    glob.attackdata.attackcount = 70
    glob.attackdata.untilnextattack = 0
  end
end)
